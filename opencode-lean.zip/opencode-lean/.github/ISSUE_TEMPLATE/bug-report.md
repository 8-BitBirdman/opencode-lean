---
name: Bug report
about: A rule is producing bad output or behaving unexpectedly
title: 'bug: '
labels: bug
assignees: ''
---

**Which rule triggered the bad behavior?**

**What model were you using?**
e.g. claude-sonnet-4, gpt-4o, etc.

**What did you ask?**

**What did the model output?**

**What should it have output?**

**Any other context?**
