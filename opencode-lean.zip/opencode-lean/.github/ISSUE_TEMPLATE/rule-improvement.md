---
name: Rule improvement
about: Suggest a tighter or better-worded rule
title: 'rule: '
labels: rule
assignees: ''
---

**Which rule?**
Name the rule this is about.

**What's wrong with it?**
Is it too vague? Too broad? Produces bad output in some cases?

**Suggested change**
Your proposed wording.

**Before/after example (optional but helpful)**
Show a model response before and after your change.
